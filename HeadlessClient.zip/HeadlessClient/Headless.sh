chmod +x RunHeadlessMono.sh
gnome-terminal -x ./RunHeadlessMono.sh